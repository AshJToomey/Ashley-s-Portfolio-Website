# Ashley Toomey - Portfolio Website

A modern, responsive portfolio website built with Flask showcasing my software development projects, professional experience, and technical skills.

## 🌟 Features

- **Interactive Project Carousel**: Navigate through 5 coding projects with smooth horizontal scrolling
- **Dark Mode Toggle**: Professional dark/light theme switching
- **Responsive Design**: Optimized for desktop, tablet, and mobile devices
- **Collapsible Sections**: Improved user experience with expandable content sections
- **Contact Form**: Working contact form with validation and feedback
- **Professional Statistics**: Quick overview of experience and project count
- **Social Integration**: Links to LinkedIn, GitHub, and direct contact information

## 🚀 Projects Showcased

1. **Football Match Performance Analyzer** - Python GUI application for analyzing football match statistics
2. **Employee Joining Date Filter** - Data filtering application with date range functionality
3. **Python Calculator** - Desktop calculator application with GUI interface
4. **Boxing Combination Generator** - Random boxing combination generator for training
5. **Event-Driven Player Registration System (Football-Themed)** - Registration system with pytest testing

## 🛠️ Technology Stack

- **Backend**: Python Flask
- **Frontend**: HTML5, CSS3, JavaScript
- **Styling**: Custom CSS with responsive design
- **Icons**: Feather Icons
- **Deployment**: Gunicorn WSGI server

## 📋 Prerequisites

- Python 3.7+
- pip package manager

## 🔧 Installation & Setup

1. **Clone the repository**
   ```bash
   git clone https://github.com/AshJToomey/portfolio-website.git
   cd portfolio-website
   ```

2. **Create a virtual environment** (recommended)
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Set environment variables**
   ```bash
   export SESSION_SECRET="your-secret-key-here"
   ```

5. **Run the application**
   ```bash
   python app.py
   ```

6. **Access the website**
   Open your browser and navigate to `http://localhost:5000`

## 🚀 Production Deployment

For production deployment with Gunicorn:

```bash
gunicorn --bind 0.0.0.0:5000 --reuse-port --reload main:app
```

## 📁 Project Structure

```
portfolio-website/
├── app.py                 # Main Flask application
├── main.py               # Application entry point
├── requirements.txt      # Python dependencies
├── static/
│   ├── css/
│   │   └── style.css    # Custom styling
│   ├── js/
│   │   └── script.js    # Interactive functionality
│   ├── images/          # Project screenshots
│   └── Ashley_James_Toomey_CV_2025.txt
├── templates/
│   ├── layout.html      # Base template
│   └── index.html       # Main portfolio page
└── README.md
```

## ✨ Key Features Explained

### Project Carousel
- Horizontal scrolling through projects
- Navigation arrows and dot indicators
- Responsive design for all screen sizes

### Dark Mode
- Toggle between light and dark themes
- Persistent user preference
- Smooth transitions

### Contact Form
- Form validation
- Success/error messaging
- Professional contact information display

### Responsive Design
- Mobile-first approach
- Flexible grid layouts
- Optimized images and typography

## 🎨 Customization

### Adding New Projects
Edit the `projects` list in `app.py`:

```python
projects = [
    {
        "title": "Your Project Name",
        "description": "Project description here",
        "image": "your-image.png",
        "github": "https://github.com/yourusername/your-repo",
        "tags": ["Python", "Flask", "JavaScript"]
    }
]
```

### Updating Skills
Modify the `skills` dictionary in `app.py` to reflect your technical capabilities.

### Styling Changes
Update `static/css/style.css` to customize colors, fonts, and layout.

## 📱 Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## 🤝 Contributing

This is a personal portfolio project. For suggestions or improvements, please feel free to open an issue or reach out directly.

## 📄 License

This project is open source and available under the [MIT License](LICENSE).

## 📞 Contact

- **Email**: ashleytoomey@hotmail.com
- **Phone**: 07376 457737
- **LinkedIn**: [linkedin.com/in/ashley-toomey-534601175/](https://www.linkedin.com/in/ashley-toomey-534601175/)
- **GitHub**: [github.com/AshJToomey](https://github.com/AshJToomey)

---

Built with ❤️ by Ashley Toomey