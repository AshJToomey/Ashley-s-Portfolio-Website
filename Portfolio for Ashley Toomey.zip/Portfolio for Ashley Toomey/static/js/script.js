// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Dark mode toggle functionality
    const darkModeToggle = document.getElementById('darkModeToggle');
    
    // Check for saved theme preference or prefer-color-scheme
    const prefersDarkMode = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    const savedTheme = localStorage.getItem('theme');
    
    // Apply saved theme or default based on system preference
    if (savedTheme === 'dark' || (!savedTheme && prefersDarkMode)) {
        document.body.classList.add('dark-mode');
        darkModeToggle.checked = true;
    }
    
    // Toggle dark mode when switch is clicked
    darkModeToggle.addEventListener('change', function() {
        if (this.checked) {
            document.body.classList.add('dark-mode');
            localStorage.setItem('theme', 'dark');
        } else {
            document.body.classList.remove('dark-mode');
            localStorage.setItem('theme', 'light');
        }
    });
    
    // Implement smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);
            
            if (targetElement) {
                // Scroll smoothly to the target element
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Implement fade-in animation for sections
    const fadeElements = document.querySelectorAll('.fade-in');
    
    // Function to check if element is in viewport
    function isInViewport(element) {
        const rect = element.getBoundingClientRect();
        return (
            rect.top <= (window.innerHeight || document.documentElement.clientHeight) * 0.8
        );
    }
    
    // Function to handle scroll animation
    function handleScrollAnimation() {
        fadeElements.forEach(element => {
            if (isInViewport(element)) {
                element.classList.add('visible');
            }
        });
    }
    
    // Initial check for elements in viewport
    handleScrollAnimation();
    
    // Check for elements on scroll
    window.addEventListener('scroll', handleScrollAnimation);
});

// Collapsible section functionality
function toggleSection(sectionId) {
    const section = document.getElementById(sectionId);
    const content = section.querySelector('.section-content');
    const icon = section.querySelector('.toggle-icon');
    
    if (content.classList.contains('collapsed')) {
        content.classList.remove('collapsed');
        icon.classList.remove('rotated');
        icon.textContent = '▼';
    } else {
        content.classList.add('collapsed');
        icon.classList.add('rotated');
        icon.textContent = '▶';
    }
}

// Project carousel functionality
let currentProject = 0;
const totalProjects = document.querySelectorAll('.project-card').length;

function scrollProjects(direction) {
    const container = document.querySelector('.project-container');
    const containerWidth = container.offsetWidth;
    
    currentProject += direction;
    
    // Loop around if at the ends
    if (currentProject < 0) {
        currentProject = totalProjects - 1;
    } else if (currentProject >= totalProjects) {
        currentProject = 0;
    }
    
    container.scrollTo({
        left: currentProject * containerWidth,
        behavior: 'smooth'
    });
    
    updateIndicators();
}

function goToProject(index) {
    const container = document.querySelector('.project-container');
    const containerWidth = container.offsetWidth;
    
    currentProject = index;
    
    container.scrollTo({
        left: currentProject * containerWidth,
        behavior: 'smooth'
    });
    
    updateIndicators();
}

function updateIndicators() {
    const indicators = document.querySelectorAll('.indicator');
    indicators.forEach((indicator, index) => {
        if (index === currentProject) {
            indicator.classList.add('active');
        } else {
            indicator.classList.remove('active');
        }
    });
}

// Initialize carousel on page load
document.addEventListener('DOMContentLoaded', function() {
    if (document.querySelector('.project-carousel')) {
        updateIndicators();
    }
});
