import os
from flask import Flask, render_template, request, flash, redirect, url_for

# Create a Flask application instance
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "ashley-portfolio-secret-key")

# Define route for the home page
@app.route('/')
def home():
    # Projects data with descriptions and tags
    projects = [
        {
            "title": "Football Match Performance Analyzer",
            "description": "As a lifelong Arsenal fan and football enthusiast, I created this Python-based tool to analyze football player performance — from Sunday League to Premier League! The app processes player statistics using pandas, calculates key metrics like pass accuracy and top goal scorers, and visualizes performance using matplotlib. It's perfect for anyone looking to gain insights into individual or team performance in a simple, data-driven way.",
            "image": "Football-Match-Performance-Analyzer.png",
            "tags": ["Python", "Pandas", "Matplotlib", "Data Analysis"],
            "github": "https://github.com/AshJToomey/Ashley-s-Football-Match-Performance-Analyzer"
        },
        {
            "title": "Employee Joining Date Filter",
            "description": "A GUI application that filters employee data from CSV files based on joining dates. Features an intuitive interface with file browsing, date range selection, and filtered results display.",
            "image": "Joining-Date-Filter.png", 
            "tags": ["Python", "GUI", "Tkinter", "CSV Processing", "Date Filtering"],
            "github": "https://github.com/AshJToomey/Ashley-s-Joining-date-filter"
        },
        {
            "title": "Python Calculator",
            "description": "A desktop GUI calculator application featuring a clean interface with input fields for numbers, dropdown operation selection, and instant calculation results. Built with Python's Tkinter framework.",
            "image": "Python-Calculator.png",
            "tags": ["Python", "GUI", "Tkinter", "Calculator", "Desktop App"],
            "github": "https://github.com/AshJToomey/Ashley-s-Python-Calculator"
        },
        {
            "title": "Boxing Combination Generator",
            "description": "A desktop GUI application that generates random boxing combinations for training. Features a simple interface with a generate button that produces varied punch sequences displayed in an easy-to-read format.",
            "image": "Python-Random-Boxing-Combination-Program.png",
            "tags": ["Python", "GUI", "Tkinter", "Random Generation", "Sports Training"],
            "github": "https://github.com/AshJToomey/Ashley-s-Random-Boxing-Combination-Program"
        },
        {
            "title": "Event-Driven Player Registration System (Football-Themed)",
            "description": "A Python GUI app that demonstrates event-driven architecture through a fun, football-inspired player registration system. Built with Tkinter, it allows users to register a player, track goals, and automatically trigger actions like notifying teammates and sending messages. Features a clean interface, modular code, and automated testing with pytest.",
            "image": "Event-Driven Player Registration System.png",
            "tags": ["Python", "GUI", "Tkinter", "Event-Driven Architecture", "OOP", "Pytest"],
            "github": "https://github.com/AshJToomey/Event-Driven-Player-Registration-System"
        }
    ]

    # Skills organized by category
    skills = {
        "Programming Languages": ["Python", "JavaScript", "SQL", "HTML5", "CSS3", "Java", "C++"],
        "Frameworks & Libraries": ["Flask", "Django (basic)", "Bootstrap", "jQuery", "Pandas", "NumPy", "Matplotlib", "Git"],
        "Software & Platforms": ["Oracle ERP Cloud", "Microsoft Dynamics 365", "Zendesk", "WordPress", "VS Code", "PyCharm"],
        "Cloud & DevOps": ["Microsoft Azure (Fundamentals)", "AWS (introductory knowledge)", "Docker", "Linux"],
        "Soft Skills": ["Problem Solving", "Communication", "Teamwork", "Time Management", "Leadership", "Adaptability"]
    }

    return render_template('index.html', projects=projects, skills=skills)

@app.route('/contact', methods=['POST'])
def contact():
    """Handle contact form submissions"""
    try:
        name = request.form.get('name')
        email = request.form.get('email')
        subject = request.form.get('subject')
        message = request.form.get('message')
        
        # Basic validation
        if not all([name, email, subject, message]):
            flash('All fields are required.', 'error')
            return redirect(url_for('home') + '#contact')
        
        # Here you could integrate with an email service like SendGrid, Mailgun, etc.
        # For now, we'll simulate successful submission
        flash(f'Thank you {name}! Your message has been received. I will get back to you soon.', 'success')
        
        # Log the message (in a real application, you'd send an email or save to database)
        print(f"Contact form submission from {name} ({email}): {subject} - {message}")
        
        return redirect(url_for('home') + '#contact')
        
    except Exception as e:
        flash('Sorry, there was an error sending your message. Please try again.', 'error')
        return redirect(url_for('home') + '#contact')

if __name__ == '__main__':
    # Run the app with host set to 0.0.0.0 to make it externally visible
    app.run(host='0.0.0.0', port=5000, debug=True)
